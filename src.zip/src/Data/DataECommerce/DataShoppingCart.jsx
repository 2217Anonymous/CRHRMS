export const shopingData = [
        {
            id: 4,
            preview: require("../../assets/images/products/3.jpg"),
            heading: 'Flower Pot for Home Decor',
            price1: '$568',
            price2: '$568',
            quantity: 1,
        },
        {
            id: 1,
            preview: require("../../assets/images/products/11.jpg"),
            heading: 'Stylish Rockerz 255 Ear Pods',
            price1: '$1,027',
            price2: '$2,054',
            quantity: 2,
        },
        {
            id: 3,
            preview: require("../../assets/images/products/9.jpg"),
            heading: 'White Tshirt for Men',
            price1: '$1,589',
            price2: '$4,767',
            quantity: 3,
        },
        {
            id: 2,
            preview: require("../../assets/images/products/8.jpg"),
            heading: 'Candy Pure Rose Water',
            price1: '$1,027',
            price2: '$4,108',
            quantity: 4,
        },
        {
            id: 7,
            preview: require("../../assets/images/products/5.jpg"),
            heading: 'Black Digital Camera',
            price1: '$1,589',
            price2: '$3,178',
            quantity: 2,
        }
    ];

    // const topproductData = [
    //     { 
    //         id: 1,
    //         pic: require("../../assets/images/products/11.jpg"),
    //         heading: 'Hand Bag',
    //         price: ''
    //     },
    //     { 
    //         id: 1,
    //         pic: require("../../assets/images/pngs/5.png"),
    //         heading: 'Chair',
    //         price: ''
    //     },
    //     { 
    //         id: 1,
    //         pic: require("../../assets/images/products/1.jpg"),
    //         heading: 'Laptop Bag',
    //         price: ''
    //     },
    //     { 
    //         id: 1,
    //         pic: require("../../assets/images/products/5.jpg"),
    //         heading: 'Watch',
    //         price: ''
    //     }
    // ]